$(document).ready(function() {
    // Function to fetch and display posts
    function fetchPosts() {
        $.ajax({
            url: "queries/list_posts_query.php",  
            type: "GET",
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    displayPosts(response.posts);
                } else {
                    $("#postTableBody").html("<tr><td colspan='6'>No posts found.</td></tr>");
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", error);
                $("#postTableBody").html("<tr><td colspan='6'>Error fetching posts.</td></tr>");
            }
        });
    }

    // $(document).on('click', '.edit-post-btn', function(event) {
    //     event.preventDefault(); // Prevent default link behavior (navigation)

    //     const postId = $(this).data('post_id');

    //     // Construct the URL for edit_post.php
    //     const editUrl = "edit_post.php?id=" + postId; 

    //     // Redirect to edit_post.php with the post ID
    //     window.location.href = editUrl; 
    // });

    // Function to display posts in the table
    function displayPosts(posts) {
        let tableRows = '';
        let count = 1;
        for (let post of posts) {
            const formattedDate = new Date(post.post_date).toLocaleDateString('en-ZW', { year: 'numeric', month: 'short', day: 'numeric' });

            tableRows += `
                <tr>
                    <td>${count}</td>
                    <td><img src="../img/blog/${post.image_name}" alt="${post.headline}" height="40px"></td> 
                    <td>${post.category}</td>
                    <td>${formattedDate}</td>
                    <td>${post.headline}</td>
                    <td class="flex">
                        
                        <button class="btn btn-sm btn-primary edit-post-btn" data-toggle="modal" data-target="#editPostModal" data-post-id="${post.id}">
                            <i class="far fa-edit"></i> Update
                        </button>
                        <button class="btn btn-sm btn-danger delete-post-btn" data-toggle="modal" data-target="#deletePostModal" data-post-id="${post.id}">
                            <i class="far fa-trash-alt"></i> Delete
                        </button>
                    </td>
                </tr>
            `;
            count++;
        }
        $("#postTableBody").html(tableRows); // Append rows to the table body
    }

    // Fetch posts when the page loads
    fetchPosts();
});

