$(document).ready(function() {
    // Initialize Summernote on the modal's textarea (important)
    $('#blog_content').summernote({
        placeholder: 'Write your blog content here...',
        tabsize: 2,
        height: 180, // Adjust height as needed
        toolbar: [
            ['style', ['style']],
            ['font', ['bold', 'underline', 'clear']],
            ['fontname', ['fontname']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['insert', ['link']] 
        ]
        });
    
  

    // Image preview
    $("#image_name").change(function() {
        const imageFile = this.files[0];

        if (imageFile) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#imagePreview').attr('src', e.target.result);
                $('#imagePreview').show();
            }
            reader.readAsDataURL(imageFile);
        } else {
            $('#imagePreview').attr('src', '');
            $('#imagePreview').hide();
        }
    });


    // Edit button click handler (opens the modal)
    $(document).on('click', '.edit-post-btn', function () {
        const postId = $(this).data('post-id');

        $.ajax({
            url: "queries/fetch_post_by_id.php",
            type: 'GET',
            data: { postId: postId },
            dataType: 'json',
            success: function (response) {
                if (response.status === 'success') {
                    const post = response.post;
                    // Populate the modal fields
                    $('#editPostId').val(postId);
                    $('#headline').val(post.headline);
                    $('#category').val(post.category_id);
                    $('#blog_content').summernote('code', post.blog_content);
                    if (post.image_name) {
                        $('#imagePreview').attr('src', '../img/blog/' + post.image_name);
                        $('#imagePreview').show();
                    } else {
                        $('#imagePreview').hide();
                    }

                    // Show the modal
                    $('#editPostModal').modal('show');
                } else {
                    alert(response.message); // Or show a toastr error message
                }
            },
            error: function () {
                alert("Error fetching post data.");
            }
        });
    });

    // Submit handler for the edit form
    $('#editPostForm').submit(function(event) {
        event.preventDefault();
        
        let url = "queries/update_post_query.php"; // Default URL for updates without image
        let data = $(this).serialize(); // Serialize form data

        if ($('#postImage')[0].files.length > 0) {
            // If image file is selected, use FormData and the image update URL
            url = "queries/update_post_query_image.php";
            data = new FormData(this); // Create FormData object for file upload
        }

        $.ajax({
            url: url,
            type: 'POST',
            data: data,
            dataType: 'json',
            processData: false, // Important for FormData with file uploads
            contentType: false, // Important for FormData with file uploads
            success: function(response) {
                if (response.status === 'success') {
                    // Success alert
                    $("#message-area").html('<div class="alert alert-success alert-dismissible fade show" role="alert">' + response.message + '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                    // Refresh the page or update the table row as needed
                    setTimeout(function() {
                        location.reload(); // Reload the page after 2 seconds
                    }, 2000);
                } else {
                    // Error alert
                    $("#message-area").html('<div class="alert alert-danger alert-dismissible fade show" role="alert">' + response.message + '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", error);
                // Error alert
                $("#message-area").html('<div class="alert alert-danger alert-dismissible fade show" role="alert">An error occurred. Please try again later.<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            }
        });
    });
});
