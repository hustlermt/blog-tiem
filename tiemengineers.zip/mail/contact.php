<?php
if(empty($_POST['name']) || empty($_POST['phone']) || empty($_POST['message']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
  http_response_code(500);
  exit();
}

$name = strip_tags(htmlspecialchars($_POST['name']));
$email = strip_tags(htmlspecialchars($_POST['email']));
$m_phone = strip_tags(htmlspecialchars($_POST['phone']));
$message = strip_tags(htmlspecialchars($_POST['message']));

$to = "info@tiemcivilstructuralengineers.co.zw"; // Change this email to your //
$phone = "$m_phone:  $name";
$body = "New contact form message.\n\n"."Here are the details:\n\nName: $name\n\n\nEmail: $email\n\nSubject: $m_phone\n\nMessage: $message";
$header = "From: $email";
$header .= "Reply-To: $email";	

if(!mail($to, $phone, $body, $header))
  http_response_code(500);
?>
