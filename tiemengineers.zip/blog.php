<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>TIEM Civil and Structural Engineers | BLIG | ENGINEERING ARTICLES</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="civil engineering, structural engineering, architectural engineering, project management, site inspection, electrical engineering, construction, land development, infrastructure, Zimbabwe, SADC, COMESA, engineering services, building design, construction management, project planning, land development consulting, urban development"
        name="keywords">
    <meta content="TIEM Civil & Structural Engineers: Your trusted partner for comprehensive engineering solutions in Zimbabwe and beyond. We specialize in architectural, civil, and structural engineering, project management, construction, and land development, offering a one-stop shop for all your project needs. "
        name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Lato&family=Oswald:wght@200;300;400&display=swap"
        rel="stylesheet">

    <!-- CSS Libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <style>
      .truncate-3-sentences {
      display: block; /* or inline-block */
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap; /* Prevent line breaks */
    }

    </style>

</head>

<body class="page">


    <?php include 'partials/navbar.php' ?>
    
    <!-- content here -->
    <div class="blog blog-page mt-125">
      <div class="container">
        <div class="section-header">
          
          <h2>Recent Blog Articles</h2>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="blog-item">
              <div class="blog-img">
                <img src="img/services-1.jpg" alt="Tiem Civil and Structural Engineers Article" />
              </div>
              <div class="blog-content">
                <h2 class="blog-title text-truncate"> Building a Sustainable Zimbabwe</h2>
                <div class="blog-meta">
                  <a href="#" class="text-truncate"><i class="fa fa-list-alt"></i> Civil Engineering</a>
                </div>
                <div class="blog-meta">
                  <i class="fa fa-calendar-alt"></i>
                  <p>21-May-2024</p>
                  
                </div>
                <div class="blog-text ">
                  <p class="truncate-3-sentence">
                  Explore how civil engineering projects in Zimbabwe are incorporating sustainable 
                  practices to address environmental challenges and create a greener future.
                  
                  </p>
                  <a class="btn" href="#">Read More</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="blog-item">
              <div class="blog-img">
                <img src="img/services-1.jpg" alt="Tiem Civil and Structural Engineers Article" />
              </div>
              <div class="blog-content">
                <h2 class="blog-title text-truncate"> The Future of Urban Development</h2>
                <div class="blog-meta">
                  <i class="fa fa-list-alt"></i>
                  <a href="">Trends and Innovations</a>
                </div>
                <div class="blog-meta">
                  <i class="fa fa-calendar-alt"></i>
                  <p>20-May-2024</p>
                  
                </div>
                <div class="blog-text">
                  <p>
                  Discuss emerging trends in urban planning and design in Zimbabwe, highlighting innovative solutions
                   for housing, transportation, and infrastructure.
                  </p>
                  <a class="btn" href="#">Read More</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="blog-item">
              <div class="blog-img">
                <img src="img/services-1.jpg" alt="Tiem Civil and Structural Engineers Article" />
              </div>
              <div class="blog-content">
                <h2 class="blog-title text-truncate"> Building a Sustainable Zimbabwe</h2>
                <div class="blog-meta">
                  <i class="fa fa-list-alt"></i>
                  <a href="">Engineering Expertise</a>
                </div>
                <div class="blog-meta">
                  <i class="fa fa-calendar-alt"></i>
                  <p>19-May-2024</p>
                  
                </div>
                <div class="blog-text">
                  <p>
                  Explain the critical role of structural engineers in ensuring the safety and resilience of buildings and
                   infrastructure in Zimbabwe, especially in earthquake-prone areas.
                  </p>
                  <a class="btn" href="#">Read More</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="blog-item">
              <div class="blog-img">
                <img src="img/services-1.jpg" alt="Tiem Civil and Structural Engineers Article" />
              </div>
              <div class="blog-content">
                <h2 class="blog-title text-truncate"> TIEM's Collaborative Approach Delivers Results</h2>
                <div class="blog-meta">
                  <i class="fa fa-list-alt"></i>
                  <a href="">Project Management</a>
                </div>
                <div class="blog-meta">
                  <i class="fa fa-calendar-alt"></i>
                  <p>18-May-2024</p>
                  
                </div>
                <div class="blog-text">
                  <p>
                  Explore how civil engineering projects in Zimbabwe are incorporating sustainable 
                  practices to address environmental challenges and create a greener future.
                  </p>
                  <a class="btn" href="#">Read More</a>
                </div>
              </div>
            </div>
          </div>
          
        </div>
        <div class="row">
          <div class="col-12">
            <ul class="pagination justify-content-center">
              <li class="page-item disabled">
                <a class="page-link" href="#">Previous</a>
              </li>
              <li class="page-item"><a class="page-link" href="#">1</a></li>
              <li class="page-item active">
                <a class="page-link" href="#">2</a>
              </li>
              <li class="page-item"><a class="page-link" href="#">3</a></li>
              <li class="page-item"><a class="page-link" href="#">Next</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    
    <div class="footer">
        <div class="container copyright">
            <div class="row">
                <div class="col-md-6">
                    <p>&copy; <a href="#">Tiem Civil & Structural Engineers</a></p>
                </div>
                <div class="col-md-6">
                    <p>Designed By <a href="https://codewand.co.zw">Codewand</a></p>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    <script>
      $(document).ready(function() {
        $('.truncate-3-sentences').each(function() {
          var text = $(this).text();
          var sentences = text.split(/(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s/g); // Split into sentences, considering abbreviations and initials
          if (sentences.length > 3) {
            var truncatedText = sentences.slice(0, 3).join(' ') + '.'; // Join first 3 sentences
            $(this).text(truncatedText + '...'); // Add ellipsis
          }
        });
      });
    </script>
</body>

</html>